document.querySelector(".sign-in-form").addEventListener("submit", (e) => {
    e.preventDefault();
  
    const email = document.querySelector('.sign-in-form input[type="text"]').value;
    const password = document.querySelector('.sign-in-form input[type="password"]').value;
  
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log("Login successful!", user);
        alert("Logged in successfully!");
        // Redirect to a dashboard or homepage
        window.location.href = "dashboard.html";
      })
      .catch((error) => {
        console.error("Error logging in", error.message);
        alert("Error: " + error.message);
      });
  });
  