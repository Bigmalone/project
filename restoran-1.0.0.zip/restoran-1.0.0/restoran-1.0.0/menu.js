 // Get the reset cart button
 const resetCartButton = document.getElementById('reset-cart');
 // Function to reset the cart
 function resetCart() {
   // Clear the cart items array
   cartItems.length = 0;
   // Update the cart counter
   cartCounter.textContent = '0';
   // Remove cart data from local storage
   localStorage.removeItem('cart');
   // Optional: Notify the user
   alert('The cart has been reset.');
 }
 // Add event listener to the reset button
 resetCartButton.addEventListener('click', resetCart);
 // Initialize cart items array and counter
 const cartItems = [];
 const cartCounter = document.getElementById('cart-counter');
 // Function to add an item to the cart
 function addToCart(itemName, itemPrice) {
   // Add item to cart array
   cartItems.push({ name: itemName, price: itemPrice });
   // Update cart counter
   cartCounter.textContent = cartItems.length;
   // Optionally, store cart in local storage to persist data
   localStorage.setItem('cart', JSON.stringify(cartItems));
 }
 // Add event listeners to all "Add" buttons
 document.querySelectorAll('.btn-sm').forEach((button) => {
   button.addEventListener('click', (event) => {
     const itemContainer = button.closest('.d-flex'); // Get the parent container
     const itemName = itemContainer.querySelector('span').textContent; // Get the item name
     const itemPrice = itemContainer.querySelector('.text-primary').textContent; // Get the item price
     // Add the item to the cart
     addToCart(itemName, itemPrice);
   });
 });
 // Retrieve cart items from local storage on page load (if needed)
 window.addEventListener('load', () => {
   const savedCart = JSON.parse(localStorage.getItem('cart'));
   if (savedCart) {
     cartItems.push(...savedCart);
     cartCounter.textContent = cartItems.length;
   }
 });