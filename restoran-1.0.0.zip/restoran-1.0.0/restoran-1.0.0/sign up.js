document.querySelector(".sign-up-form").addEventListener("submit", (e) => {
    e.preventDefault();
  
    const email = document.querySelector('.sign-up-form input[type="email"]').value;
    const password = document.querySelector('.sign-up-form input[type="password"]').value;
  
    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        console.log("Account created!", user);
        alert("Account created successfully!");
        // Automatically log the user in or redirect
        window.location.href = "dashboard.html";
      })
      .catch((error) => {
        console.error("Error signing up", error.message);
        alert("Error: " + error.message);
      });
  });
  