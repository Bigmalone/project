const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

// Authenticate user (Login)
async function authenticateUser(email, password) {
  try {
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    if (response.ok) {
      alert('Login successful');
      // Store JWT token (in localStorage or cookies)
      localStorage.setItem('token', data.token);
      window.location.href = 'vendor.html'; // Redirect to vendor page
    } else {
      alert(data.message || 'Login failed');
    }
  } catch (error) {
    alert('Error during authentication');
  }
}

// Register user (Sign-up)
async function registerUser(username, email, password) {
  try {
    const response = await fetch('http://localhost:3000/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });

    if (response.ok) {
      alert('Registration successful');
      window.location.href = 'vendor.html'; // Redirect to vendor page
    } else {
      const data = await response.json();
      alert(data.message || 'Registration failed');
    }
  } catch (error) {
    alert('Error during registration');
  }
}
