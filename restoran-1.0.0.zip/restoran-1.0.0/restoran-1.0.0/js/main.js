$(".order").click(function (e) {
    let button = $(this);
  
    if (!button.hasClass("animate")) {
      button.addClass("animate");
      setTimeout(() => {
        button.removeClass("animate");
      }, 10000);
    }
  });
  

// cart.js
class ShoppingCart {
    constructor() {
        this.items = this.loadCart();
        this.updateCounter();
        
        // Initialize clear cart button
        const clearCartBtn = document.getElementById('clear-cart');
        if (clearCartBtn) {
            clearCartBtn.addEventListener('click', () => this.resetCart());
        }

        // Initialize add to cart buttons if we're on the menu page
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', () => {
                const name = button.getAttribute('data-name');
                const price = parseFloat(button.getAttribute('data-price'));
                this.addItem(name, price);
            });
        });
    }

    loadCart() {
        const cart = localStorage.getItem('cart');
        return cart ? JSON.parse(cart) : [];
    }

    saveCart() {
        localStorage.setItem('cart', JSON.stringify(this.items));
    }

    addItem(name, price) {
        const existingItem = this.items.find(item => item.name === name);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.items.push({
                name: name,
                price: price,
                quantity: 1
            });
        }
        
        this.saveCart();
        this.updateCounter();
    }

    updateCounter() {
        const counter = document.getElementById('cart-counter');
        if (counter) {
            const totalItems = this.items.reduce((sum, item) => sum + item.quantity, 0);
            counter.textContent = totalItems;
        }
    }

    resetCart() {
        this.items = [];
        this.saveCart();
        this.updateCounter();
        this.displayCart();
    }

    displayCart() {
        const cartContainer = document.getElementById('cart-items');
        if (!cartContainer) return;

        cartContainer.innerHTML = '';
        
        if (this.items.length === 0) {
            cartContainer.innerHTML = `
                <div class="text-center">
                    <p class="lead">Your cart is empty</p>
                    <a href="menu.html" class="btn btn-primary">Return to Menu</a>
                </div>`;
            return;
        }

        let total = 0;
        
        // Create table for cart items
        const table = document.createElement('table');
        table.className = 'table table-hover';
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;

        this.items.forEach(item => {
            const itemTotal = item.price * item.quantity;
            total += itemTotal;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.name}</td>
                <td>GH₵ ${item.price.toFixed(2)}</td>
                <td>${item.quantity}</td>
                <td>GH₵ ${itemTotal.toFixed(2)}</td>
            `;
            table.querySelector('tbody').appendChild(row);
        });

        // Add total row
        const totalRow = document.createElement('tr');
        totalRow.className = 'table-primary';
        totalRow.innerHTML = `
            <td colspan="3" class="text-end"><strong>Total:</strong></td>
            <td><strong>GH₵ ${total.toFixed(2)}</strong></td>
        `;
        table.querySelector('tbody').appendChild(totalRow);

        cartContainer.appendChild(table);
    }
}

// Initialize cart when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const cart = new ShoppingCart();
    cart.displayCart();
});





/*script for vendor dashboard*/
function acceptOrder(orderId) {
    const order = document.getElementById(`order-${orderId}`);
    const history = document.getElementById('order-history');
    const historyItem = document.createElement('li');
    historyItem.textContent = `Order #${orderId} Accepted`;
    history.appendChild(historyItem);
    order.remove();
}
function declineOrder(orderId) {
    const order = document.getElementById(`order-${orderId}`);
    const history = document.getElementById('order-history');
    const historyItem = document.createElement('li');
    historyItem.textContent = `Order #${orderId} Declined`;
    history.appendChild(historyItem);
    order.remove();
}



/*script for vendor dashboard*/



(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });
    
    
    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav : false,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });
    
})(jQuery);

