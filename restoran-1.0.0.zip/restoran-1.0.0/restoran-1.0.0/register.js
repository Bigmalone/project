document.querySelector('.sign-in-form').addEventListener('submit', function(event) {
  event.preventDefault();
  
  // Get input values
  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  // Basic validation
  if (!email || !password) {
    alert('Please fill in all fields.');
    return;
  }

  if (!validateEmail(email)) {
    alert('Please enter a valid email.');
    return;
  }

  // Call your backend API here for authentication
  authenticateUser(email, password);
});

document.querySelector('.sign-up-form').addEventListener('submit', function(event) {
  event.preventDefault();
  
  // Get input values
  const username = document.querySelector('#Username').value;
  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  // Basic validation
  if (!username || !email || !password) {
    alert('Please fill in all fields.');
    return;
  }

  if (!validateEmail(email)) {
    alert('Please enter a valid email.');
    return;
  }

  // Call your backend API here for registration
  registerUser(username, email, password);
});

// Simple email validation
function validateEmail(email) {
  const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return regex.test(email);
}
