const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

// In-memory store for orders (replace with a database in production)
let orders = [];

// Receive new orders
app.post('/api/orders', (req, res) => {
    const order = {
        ...req.body,
        status: 'pending',
        timestamp: new Date(),
        orderNumber: orders.length + 1, // Assign a unique order number
    };
    orders.push(order);
    res.status(201).json(order);
});

// Get all pending orders
app.get('/api/orders', (req, res) => {
    const pendingOrders = orders.filter(order => order.status === 'pending');
    res.json(pendingOrders);
});

// Update order status
app.put('/api/orders/:orderNumber', (req, res) => {
    const { orderNumber } = req.params;
    const { status } = req.body;

    const order = orders.find(o => o.orderNumber === Number(orderNumber));
    if (order) {
        order.status = status;
        res.json(order);
    } else {
        res.status(404).json({ error: 'Order not found' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
